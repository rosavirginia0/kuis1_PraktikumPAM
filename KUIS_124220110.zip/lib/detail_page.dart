import 'package:flutter/material.dart';

class DetailPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail Baju'),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Image.asset('assets/upn.jpg', height: 300), // Foto besar
            SizedBox(height: 20),
            Text(
              'Arah Pendidikan \nArah pendidikan UPN ”Veteran” Yogyakarta adalah mengembangkan ilmu pengetahuan dan teknologi yang dilandasi oleh nilai-nilai kedisiplinan, kejuangan, kreativitas, keunggulan, kebangsaan, dan kejujuran dalam rangka menunjang pembangunan nasional melalui bidang pendidikan tinggi dalam rangka terciptanya sumber daya manusia yang unggul di era global dengan dilandasi jiwa bela negara.\nTujuan Pendidikan\nPendidikan di UPN ”Veteran” Yogyakarta bertujuan untuk:\n1. Menyelenggarakan pendidikan dan pengajaran yang berkualitas guna menghasilkan lulusan berdaya saing global yang memiliki jiwa disiplin, berdaya juang dan, kreatif serta berwawasan kebangsaan dan mampu menjadi komponen pendukung dalam sistem pertahanan negara;\n2. Meningkatkan kuantitas dan kualitas penelitian guna:\na. Menunjang pengembangan mutu pendidikan dan pengajaran;\nb. Mengembangkan dan menerapkan ilmu pengetahuan dan teknologi (IPTEK) untuk menunjang pengabdian kepada masyarakat; dan\nc. Menghasilkan modal intelektual dan karya ilmiah dalam rangka menunjang pembangunan nasional; dan\n3. Pengembangan kegiatan pengabdian kepada masyarakat melalui\na. Penyediaan layanan ilmu pengetahuan dan teknologi (IPTEK) dalam rangka meningkatkan kesejahteraan masyarakat;\nb. Peningkatan keberdayaan masyarakat; dan\nc. Peningkatan reputasi UPN Veteran Yogyakarta.',
              style: TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}