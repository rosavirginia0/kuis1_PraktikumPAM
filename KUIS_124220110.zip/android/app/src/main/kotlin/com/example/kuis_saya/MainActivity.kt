package com.example.kuis_saya

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
